<?php
$conexion = mysqli_connect ("localhost", "root", "", "consultorio") or die ('No se pudo conectar a la base de datos'.mysqli_error($conexion));
?>