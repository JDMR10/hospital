<?php
session_start();
?>
<!DOCTYPE html>
<html>

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/consultorio.css">
    <title>Inicio</title>
</head>

<body class="bginicio">
            <?php
      //Mantiene inicio de session      
if(isset($_SESSION['id'])){
    if($_SESSION['tipo']=='PACIENTE'){
        header ('location: paciente.php');
    }else{
        header ('location: medico.php');
    }
   
}else{
   ?>
               <!--   Encabezado-->
    <header>
        <div class="container">
            <div class="row">
                <div class="col">
                    <h3>CONSULTORIO MEDICO</h3>
                </div>
                <div class="col derecha">
                    <!--               formulario inicio de session-->
                    <form class="form-inline" action="validar.php" method="post">
                        <input type="text" class="form-control centrar" name="id" id="id" placeholder="Identificación" required>&nbsp
                        <input class="form-control centrar" type="password" placeholder="Password" id="pass" name="pass"/>&nbsp
                        <button type="submit" class="btn btn-info form-control">Ingresar</button>
                    </form>
                </div>
            </div>
        </div>
    </header>
    <div class="container">
        <div class="login">
                <center>
                    <h3 class="textinicio"><b> REGISTRO DE USUARIO </b><hr></h3>
                    
                    <!--                    Formulario de registro-->
                    <form action="registro.php" method="POST">
                        <p><input type="text" class='centrar' name="id" required placeholder='Identificacion' />&nbsp&nbsp<input type="password" class='centrar' name="pass" required placeholder="Contraseña" /></p>

                        <p><input type="text" class='centrar' name="apellidos" required placeholder='Apellidos' />&nbsp&nbsp<input type="text" class='centrar' name="nombres" required placeholder="Nombres" /></p>

                        <p><input type="text" class='centrar' name="tel" required placeholder='Telefono' /></p>

                        <textarea name="direccion" class="form-control centrar" rows="2" placeholder="Escriba Aqui su dirección" required></textarea><br>

                        <p><input type="number" class='centrar' name="peso" required placeholder='Peso' />&nbsp&nbsp<input type="number" class='centrar' name="estatura" required placeholder="Estatura" /></p>
                        <p class="centrar"><i>GENERO</i></p>
                        <p><input type="radio" name="genero" value="M" checked>&nbsp Masculino &nbsp&nbsp&nbsp&nbsp&nbsp
                            <input type="radio" name="genero" value="F">&nbsp Femenino</p>
                        <p class="centrar"><i>GRUPO SANGUINEO</i></p>
                        <select class="centrar" name="gruposanguineo">
                            <option value="a+">A+</option>
                            <option value="a-">A-</option>
                            <option value="b+">B+</option>
                            <option value="b-">B-</option>
                            <option value="o+">O+</option>
                            <option value="o-">O-</option>
                            <option value="AB+">AB+</option>
                            <option value="ab-">AB-</option>
                        </select>
                        <br><br>
                        <p class="centrar"><i>TIPO DE USUARIO</i></p>
                        <p><input type="radio" name="tipo" value="paciente" checked>&nbsp Paciente &nbsp&nbsp&nbsp&nbsp&nbsp
                            <input type="radio" name="tipo" value="medico">&nbsp Medico</p><br>
                        <input type="submit" name="accion" class="btn btn-danger btn-lg" value="Registro" />
                    </form>
                </center>
                <br>
                <?php
   }
?>
        </div>
    </div>
    <!-- jQuery first, then Tether, then Bootstrap JS. -->
    <script type="text/javascript" src="js/login.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>

</html>