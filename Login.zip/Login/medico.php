<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
    <link rel="stylesheet" href="css/login.css">
    <title>Inicio</title>
</head>
<body>
    <header>
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <center><h3>CONSULTORIO</h3></center>
                        </div>
                    </div>
                </div>
            </header>
            <nav class="navbar navbar-toggleable-md navbar-inverse bg-inverse">
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                  </button>
                <a class="navbar-brand" href="#">Inicio</a>
                <div class="collapse navbar-collapse" id="navbarText">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Citas</a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                <a class="dropdown-item" href="#">Reservar</a>
                                <a class="dropdown-item" href="#">Modificar</a>
                                <a class="dropdown-item" href="#">Cancelar</a>
                            </div>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Opciones Usuario</a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                <a class="dropdown-item" href="#">Modificar datos</a>
                            </div>
                        </li>

                    </ul>
                    <span class="navbar-text">
      <?php echo $_SESSION['nombres'];?> &nbsp&nbsp&nbsp<a href="cerrarsesion.php" class="btn btn-primary btn-sm">Cerar sesion</a>
    </span>
                </div>
            </nav>
</body>
</html>