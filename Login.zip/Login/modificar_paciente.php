<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
    <link rel="stylesheet" href="css/login.css">
    <title>Bienvenida</title>
</head>

<body>
<center>
<header>
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <center><h3>CONSULTORIO MEDICO</h3></center>
                        </div>
                    </div>
                </div>
            </header>
            <nav class="navbar navbar-toggleable-md navbar-inverse bg-inverse">
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                  </button>
                <a class="navbar-brand" href="#">Inicio</a>
                <div class="collapse navbar-collapse" id="navbarText">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Citas</a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                <a class="dropdown-item" href="#">Reservar</a>
                                <a class="dropdown-item" href="#">Modificar</a>
                                <a class="dropdown-item" href="#">Cancelar</a>
                            </div>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Opciones Usuario</a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                <a class="dropdown-item" href="#">Modificar datos</a>
                            </div>
                        </li>

                    </ul>
                    <span class="navbar-text">
      <?php echo $_SESSION['nombres'];?> &nbsp&nbsp&nbsp<a href="cerrarsesion.php" class="btn btn-primary btn-sm">Cerar sesion</a>
    </span>
                </div>
            </nav>
        <?php

if(isset($_POST['id'])){
  ?>
              <center>
                    <h3 class="textinicio"><b> MODIFICAR DATOS </b></h3><br>

                    <!--                    Formulario de registro-->
                    <form class="form-control" action="registro.php" method="POST">
                        <p class="centrar"><i>DATOS PERSONALES</i></p>
                        <p><input type="text" class='centrar' name="id" required placeholder='Identificacion' />&nbsp&nbsp<input type="password" class='centrar' name="pass" required placeholder="Contraseña" /></p>

                        <p><input type="text" class='centrar' name="apellidos" required placeholder='Apellidos' />&nbsp&nbsp<input type="text" class='centrar' name="nombres" required placeholder="Nombres" /></p>

                        <p><input type="text" class='centrar' name="tel" required placeholder='Telefono' /></p>

                        <textarea name="direccion" class="form-control centrar" rows="2" placeholder="Escriba Aqui su dirección" required></textarea><br>

                        <p><input type="number" class='centrar' name="peso" required placeholder='Peso' />&nbsp&nbsp<input type="number" class='centrar' name="estatura" required placeholder="Estatura" /></p>
                        <p class="centrar"><i>Genero</i></p>
                        <p><input type="radio" name="genero" value="M" checked>&nbsp Masculino &nbsp&nbsp&nbsp&nbsp&nbsp
                            <input type="radio" name="genero" value="F">&nbsp Femenino</p><br>
                        <p class="centrar"><i>Tipo de sangre</i></p>
                        <select class="centrar" name="gruposanguineo">
                            <option value="a+">A+</option>
                            <option value="a-">A-</option>
                            <option value="b+">B+</option>
                            <option value="b-">B-</option>
                            <option value="o+">O+</option>
                            <option value="o-">O-</option>
                            <option value="AB+">AB+</option>
                            <option value="ab-">AB-</option>
                        </select>
                        <hr>

                        <p class="centrar"><i>TIPO DE USUARIO</i></p>
                        <p><input type="radio" name="tipo" value="paciente" checked>&nbsp Paciente &nbsp&nbsp&nbsp&nbsp&nbsp
                            <input type="radio" name="tipo" value="medico">&nbsp Medico</p><br>
                        <input type="submit" name="accion" class="btn btn-primary" value="Registro" />
                    </form>
                </center>
                <br>
                <br><br>
          
  
   <?php
    
}else {
      if(isset($_SESSION['id']))  {
          if($_SESSION['tipo']=='PACIENTE'){
        header ('location: paciente.php');
        }else{
        header ('location: medico.php');
        }
         
    }else {
          echo "<br><br><h3 class='texterror'>AVISO:</h3>";
          echo "<h3 class='texterror'>Acceso Restringido</h3>";
          echo"<br><a href='inicio.php' class='btn btn-primary'>Inicio</a>";      }
   }
?>
    </center>

    <!-- jQuery first, then Tether, then Bootstrap JS. -->
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
</body>

</html>