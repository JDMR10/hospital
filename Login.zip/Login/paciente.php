<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/consultorio.css">
    <link href="https://jdmr10.github.io/pdw2/css/metro.css" rel="stylesheet">
    <link href="https://jdmr10.github.io/pdw2/css/metro-icons.css" rel="stylesheet">
    <link href="https://jdmr10.github.io/pdw2/css/metro-responsive.css" rel="stylesheet">

    <script src="https://jdmr10.github.io/pdw2/js/jquery-2.1.3.min.js"></script>
    <script src="https://jdmr10.github.io/pdw2/js/metro.js"></script>
    <title>Paciente</title>
</head>
<?php
if(isset($_SESSION['id']))  {
          if($_SESSION['tipo']=='PACIENTE'){
        ?>

    <body>
        <ul class="nav nav-tabs">
            <li class="active"><a data-toggle="tab" href="#home">Inicio</a></li>
            <li><a data-toggle="tab" href="#menu1">Reservar cita</a></li>
            <li><a data-toggle="tab" href="#menu2">Modificar cita</a></li>
            <li><a data-toggle="tab" href="#menu3">Cancelar cita</a></li>
            <li><a data-toggle="tab" href="#menu4">Editar datos personales</a></li>
            <li><a href="cerrarsesion.php">Cerrar sesión</a></li>
        </ul>

        <div class="tab-content">
            <div id="home" class="tab-pane fade in active">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <h2>Bienvenido,
                                <?php echo $_SESSION['nombres']?>
                            </h2>
                            <p class="parrafo">En el consultorio sabemos que lo más importante es la salud de nuestros pacientes, es por esa razón que contamos con un gran equipo medico disponible a tus necesidades. Ademas, contamos con servicios de visitas medicas y servicio de ambulancia para casos de emergencia.</p>
                            <p>Contamos con sedes en mas de 20 ciudades del país y tenemos convenios con las mejores clinicas y hospitales a nivel nacional e internacinal.</p><br>
                        </div>
                        <div class="col-md-6">
                           <br>
                            <img src="ico/bienvenidapaciente1.jpg">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <img src="ico/bienvenidapaciente2.jpg">
                        </div>
                        <div class="col-md-6">
                           <br>
                            <p class="parrafo">Aqui tienes las opciones de apartar tus citas y solicitar los servicios que desees. <br>Puedes:
                                <ul>
                                    <li>Apartar citas.</li>
                                    <li>Modificar citas.</li>
                                    <li>Cancelar citas.</li>
                                    <li>Modificar tus datos personales.</li>
                                </ul>
                            </p>
                            <p>Estamos prestos para servirles, y con gusto resolveremos cualquiera de sus inquietudes.</p><br>
                        </div>
                    </div>
                </div>
            </div>
            <div id="menu1" class="tab-pane fade">
                <center>
                   <div class="login">
                       <h3><form action="listafecha.php" method="post"  data-role="validator">
                        <div class="input-control text" data-role="datepicker" data-other-days="true" data-week-start="1" data-locale="es">
                            <input type="text" name="fecha" data-validate-func="required">
                            <button class="button"><span class="mif-calendar"></span></button>
                        </div>
                        <button class="btn btn-primary btn-lg" type="submit">Agendar</button>
                    </div>
                    </form></h3><br>
                   </div>
                </center>
            </div>
            <div id="menu2" class="tab-pane fade">
                <h3>Menu 2</h3>
                <p>Some content in menu 2.</p>
            </div>
        </div>
        <?php
        }else{
        header ('location: medico.php');
        }
         
    }else {
          echo "<center><br><br><h3 class='texterror'>AVISO:</h3>";
          echo "<h3 class='texterror'>Acceso Restringido</h3>";
          echo"<br><a href='inicio.php' class='btn btn-primary'>Inicio</a></center>";    
}
?>
            <!-- Centered Pills -->

            <!-- jQuery first, then Tether, then Bootstrap JS. -->
            <script type="text/javascript" src="js/login.js"></script>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
            <script src="js/bootstrap.min.js"></script>
    </body>

</html>