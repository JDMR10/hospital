<!DOCTYPE html>
<html>
<head>
  <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/consultorio.css">
  <title>Registro</title>
</head>
<body>
<!--   Encabezado-->
    <header>
        <div class="container">
            <div class="row">
                <div class="col">
                    <h3>CONSULTORIO MEDICO</h3>
                </div>
                <div class="col derecha">
                    <!--               formulario inicio de session-->
                    <form class="form-inline" action="validar.php" method="post">
                        <input type="text" class="form-control centrar" name="id" id="id" placeholder="Identificación" required>&nbsp
                        <input class="form-control centrar" type="password" placeholder="Password" id="pass" name="pass"/>&nbsp
                        <button type="submit" class="btn btn-info form-control">Ingresar</button>
                    </form>
                </div>
            </div>
        </div>
    </header>
<div class="container">
   <div class="login"><br>
<?php

//conexion
include 'cn.php';

//captura de datos
$id=$_POST['id'];
$pass=$_POST['pass'];
$apellidos=$_POST['apellidos'];
$apellidos=strtoupper($apellidos);
$nombres=$_POST['nombres'];
$nombres=strtoupper($nombres);
$tel=$_POST['tel'];
$dir=$_POST['direccion'];
$dir=strtoupper($dir);
$genero=$_POST['genero'];
$tipo=$_POST['tipo'];
$peso=$_POST['peso'];
$estatura=$_POST['estatura'];
$gruposanguineo=$_POST['gruposanguineo'];
$accion=$_POST['accion'];
   //consulta de validacion
    $consulta = "SELECT * FROM personas WHERE id = '$id' ";
    $resultado = mysqli_query($conexion, $consulta);
    $row = mysqli_fetch_row($resultado);

    if (empty($row)){
    //Ingreso
        $ingreso="INSERT INTO `personas` (`id`,`password`,`apellidos`,`nombres`,`genero`,`telefono`,`direccion`,`estatura`,`peso`,`gruposanguineo`,`tipo_persona`,`estado`,`fecha_fallecimiento`) VALUES ('$id','$pass','$apellidos','$nombres','$genero','$tel','$dir','$estatura','$peso','$gruposanguineo','$tipo','VIVO','NUll')";
        $resultado = mysqli_query($conexion, $ingreso);

        if(!$resultado){
            echo "<center><h3 class='texterror'>Error en el proceso registro</h3></center>";
        }else{
            ?>
            <center>
           <h2 class="textinicio">Registro exitoso</h2>
            <br><a href="inicio.php" class="btn btn-primary">Volver</a>
            </center>
            <?php
            }//fin if

    }else{
        echo "<center><p class='texterror'>AVISO:</p></center>";
        echo "<center><h3 class='texterror'>El nombre de usuario ya exite</h3></center>";
        ?>
        <center>
        <br><a href="inicio.php" class="btn btn-primary">Volver</a>
        </center>
        <?php  
    } //fin if

?>
</div>
</div>
<!-- jQuery first, then Tether, then Bootstrap JS. -->
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
</body>
</html>
