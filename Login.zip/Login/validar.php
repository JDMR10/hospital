<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/consultorio.css">
    <title>Validar</title>
</head>

<body class="bginicio">
<center>
<header>
        <div class="container">
            <div class="row">
                <div class="col">
                    <h3>CONSULTORIO MEDICO</h3>
                </div>
                <div class="col derecha">
                    <!--               formulario inicio de session-->
                    <form class="form-inline" action="validar.php" method="post">
                        <input type="text" class="form-control centrar" name="id" id="id" placeholder="Identificación" required>&nbsp
                        <input class="form-control centrar" type="password" placeholder="Password" id="pass" name="pass"/>&nbsp
                        <button type="submit" class="btn btn-info form-control">Ingresar</button>
                    </form>
                </div>
            </div>
        </div>
    </header>
        <?php
include 'cn.php';
if(isset($_POST['id'])){
  
    //Se almacenan la variables
    $id=$_POST['id'];
    $pass=$_POST['pass'];
    
    //Se realiza la consulta
    $consulta = "SELECT * FROM personas WHERE id = '$id' ";
    $resultado = mysqli_query($conexion, $consulta);
    $row = mysqli_fetch_assoc($resultado);
    
    //Si row esta vacio el usuario no existe
    if (empty($row)){
        echo"<div class='alerta'>";
        echo "<p class='texterror'>AVISO:</p>";
        echo "<h3 class='texterror'>Usuario no existe</h3>";
        echo "<p class='texterror'>*Para acceder debe ser usuario registrado</p>";
        echo"<br><a href='index.php' class='btn btn-primary'>Volver</a></div>";
        
    }else{
        //Se valida que coincida el usuario con la contraseña
            if ($row['password']==$pass){
                
                //Inicia la sesion
                $_SESSION['id']=$id;
                $_SESSION['nombres']=$row['nombres'];
                $_SESSION['tipo']=$row['tipo_persona'];
                $_SESSION['inicio']=time();
                $_SESSION['expire']=$_SESSION['inicio']+(10*60);
                if($_SESSION['tipo']=='PACIENTE')
                    header ('location: paciente.php');
                else
                    header ('location: medico.php');
                
            }else{
                //Mensaje en caso de que no coincidan el usuario con la contraseña
                echo"<div class='alerta'>";
                echo "<p class='texterror'>AVISO:</p>";
                echo "<h3 class='texterror'>User o Pass incorrecto Verifique</h3>";
                echo"<br><a href='index.php' class='btn btn-primary'>Volver a registro</a> </div>";
            }
    }
}else {
      if(isset($_SESSION['id']))  {
          if($_SESSION['tipo']=='PACIENTE'){
        header ('location: paciente.php');
        }else{
        header ('location: medico.php');
        }
         
    }else {
          echo"<div class='alerta'>";
          echo "<h3 class='texterror'>AVISO:</h3>";
          echo "<h3 class='texterror'>Acceso Restringido</h3>";
          echo"<br><a href='index.php' class='btn btn-primary'>Inicio</a></div>";      
      }
   }
?>
    </center>

    <!-- jQuery first, then Tether, then Bootstrap JS. -->
    <script type="text/javascript" src="js/login.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>

</html>